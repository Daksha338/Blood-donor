package com.sies.project.maps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocationMap {
    private static HashMap<String, HashMap<String, Integer>> locationMap = new HashMap<String, HashMap<String, Integer>>() {
        {
            put("mumbai", new HashMap<String, Integer>() {
                {
                    put("pune", 148);
                    put("nagpur", 770);
                }
            });
            put("pune", new HashMap<String, Integer>() {
                {
                    put("mumbai", 148);
                    put("nagpur", 680);
                }
            });
            put("nagpur", new HashMap<String, Integer>() {
                {
                    put("mumbai", 770);
                    put("pune", 680);
                }
            });
        }
    };

    public static String[] getClosestLocations(String location) {
        HashMap<String, Integer> locationData = locationMap.get(location);
        if (locationData != null) {
            locationData.put(location, 0);
            List<Map.Entry<String, Integer>> list = new ArrayList<>(locationData.entrySet());
            list.sort(Map.Entry.comparingByValue());
            String[] closestLocations = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                closestLocations[i] = list.get(i).getKey();
            }

            return closestLocations;
        }
        return null;
    }

    public static Integer getDistanceBetween(String fromLocation, String toLocation) {
        if (fromLocation.equalsIgnoreCase(toLocation)) {
            return 0;
        }
        HashMap<String, Integer> locationData = locationMap.get(fromLocation);
        if (locationData != null) {
            return locationData.get(toLocation);
        }
        return null;
    }

    public static String[] getAvailableLocations() {
        return locationMap.keySet().toArray(new String[0]);
    }
}