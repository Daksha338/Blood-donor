package com.sies.project.objects;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONArray;
import org.json.JSONObject;

public class Donors {
    private String jsonStorePath;
    private JSONArray donorList;

    public Donors(String jsonStorePath) throws IOException {
        this.jsonStorePath = jsonStorePath;
        String content = new String(Files.readAllBytes(Paths.get(jsonStorePath)));
        donorList = new JSONArray(content);
    }

    public JSONArray getDonorsAtLocationWithBloodGroup(String location, String[] bloodGroups) {
        JSONArray filteredDonors = new JSONArray();
        for (int i = 0; i < donorList.length(); i++) {
            JSONObject donor = donorList.getJSONObject(i);

            String donorLocation = donor.getString("location");
            String donorBloodGroup = donor.getString("bloodGroup");

            for (int j = 0; j < bloodGroups.length; j++) {
                if (location.equalsIgnoreCase(donorLocation) && bloodGroups[j].equalsIgnoreCase(donorBloodGroup)) {
                    filteredDonors.put(donor);
                }
            }
        }
        return filteredDonors;
    }

    public void saveDonorData(JSONObject donorData) throws IOException {
        this.donorList.put(donorData);

        FileWriter fileWriter = new FileWriter(this.jsonStorePath);
        this.donorList.write(fileWriter);
        fileWriter.close();
    }
}
