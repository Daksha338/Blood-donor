package com.sies.project.maps;

import java.util.HashMap;

public class BloodGroupMap {
    private static HashMap<String, String[]> bloodGroupMap = new HashMap<String, String[]>() {
        {
            put("A", new String[] { "A", "O" });
            put("B", new String[] { "B", "O" });
            put("AB", new String[] { "A", "B", "AB", "O" });
            put("O", new String[] { "O" });
        }
    };

    public static String[] getSuitableDonorGroups(String receiverGroup) {
        return bloodGroupMap.get(receiverGroup);
    }

    public static String[] getAvailableBloodGroups() {
        return bloodGroupMap.keySet().toArray(new String[0]);
    }
}
