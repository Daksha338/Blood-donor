package com.sies.project;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Scanner;

import com.sies.project.maps.BloodGroupMap;
import com.sies.project.maps.LocationMap;
import com.sies.project.objects.Donors;

public class Main {
    public static void main(String[] args) {
        Donors donors = null;
        String donorStorePath = "donorData.json";
        try {
            donors = new Donors(donorStorePath);
        } catch (IOException | ArrayIndexOutOfBoundsException ioEx) {
            System.out.println("Provided JSON Store Path '" + donorStorePath + "' is invalid.");
            System.exit(1);
        }

        String[] availableTypes = new String[] { "donor", "receiver" };
        String[] availableLocations = LocationMap.getAvailableLocations();
        String[] availableBloodgroups = BloodGroupMap.getAvailableBloodGroups();

        JSONObject inputTaken = takeInput(availableTypes, availableLocations, availableBloodgroups);

        switch (inputTaken.getInt("type")) {
            case 1:
                JSONObject donorData = new JSONObject();
                donorData.put("name", inputTaken.getString("name"));
                donorData.put("location", availableLocations[inputTaken.getInt("location") - 1]);
                donorData.put("bloodGroup", availableBloodgroups[inputTaken.getInt("bloodGroup") - 1]);
                try {
                    donors.saveDonorData(donorData);
                } catch (IOException ioEx) {
                    System.out.println("Failed to save data to provided JSON Store Path '" + donorStorePath + "'.");
                    System.exit(1);
                }
                System.out.println("Successfully saved donor data at '" + donorStorePath + "'");
                break;
            case 2:
                String receiverLocation = availableLocations[inputTaken.getInt("location") - 1];
                String receiverBloodGroup = availableBloodgroups[inputTaken.getInt("bloodGroup") - 1];

                String[] closestLocations = LocationMap.getClosestLocations(receiverLocation);
                String[] suitableDonorGroups = BloodGroupMap.getSuitableDonorGroups(receiverBloodGroup);

                if (closestLocations != null && suitableDonorGroups != null) {
                    JSONArray allSuitableDonors = new JSONArray();
                    for (int i = 0; i < closestLocations.length; i++) {
                        JSONArray suitableDonors = donors.getDonorsAtLocationWithBloodGroup(closestLocations[i],
                                suitableDonorGroups);
                        for (int j = 0; j < suitableDonors.length(); j++) {
                            allSuitableDonors.put(suitableDonors.getJSONObject(j));
                        }
                    }
                    if (allSuitableDonors.length() > 0) {
                        System.out.println("Suitable donors found at :");
                        for (int i = 0; i < allSuitableDonors.length(); i++) {
                            JSONObject suitableDonor = allSuitableDonors.getJSONObject(i);

                            String donorName = suitableDonor.getString("name").toUpperCase();
                            String donorBloodGroup = suitableDonor.getString("bloodGroup");
                            String donorLocation = suitableDonor.getString("location").toUpperCase();
                            Integer locationDistance = LocationMap.getDistanceBetween(receiverLocation,
                                    suitableDonor.getString("location"));

                            System.out.println((i + 1) + ". " + donorName + " [" + donorBloodGroup + "]" + " from "
                                    + donorLocation + " (" + locationDistance + " KM Away) ");
                        }
                        System.exit(0);
                    }
                }

                System.out.println("No suitable donors found!");
                break;
        }
    }

    private static JSONObject takeInput(String[] availableTypes, String[] availableLocations,
            String[] availableBloodgroups) {
        JSONObject providedInput = new JSONObject();

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter your Name: \n>>> ");
        providedInput.put("name", sc.nextLine());

        System.out.print("Who are you?\n");
        for (int i = 0; i < availableTypes.length; i++) {
            System.out.println((i + 1) + ". " + availableTypes[i]);
        }
        System.out.print(">>> ");
        providedInput.put("type", sc.nextInt());

        System.out.print("Where are you from?\n");
        for (int i = 0; i < availableLocations.length; i++) {
            System.out.println((i + 1) + ". " + availableLocations[i]);
        }
        System.out.print(">>> ");
        providedInput.put("location", sc.nextInt());

        System.out.print("What is your Blood Group?\n");
        for (int i = 0; i < availableBloodgroups.length; i++) {
            System.out.println((i + 1) + ". " + availableBloodgroups[i]);
        }
        System.out.print(">>> ");
        providedInput.put("bloodGroup", sc.nextInt());

        sc.close();
        return providedInput;
    }

}
