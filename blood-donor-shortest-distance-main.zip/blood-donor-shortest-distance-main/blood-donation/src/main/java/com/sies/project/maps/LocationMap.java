package com.sies.project.maps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocationMap {
    private static HashMap<String, HashMap<String, Integer>> locationMap = new HashMap<String, HashMap<String, Integer>>() {
        {
            put("mumbai", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 42);
                    put("central mumbai", 10);
                    put("south mumbai", 30);
                    put("western mumbai", 60);
                    put("pune", 148);
                    put("nagpur", 770);
                    put("thane", 120);
                    put("kalyan", 65);
                    put("ulhasnagar", 75);
                }
            });
            put("navi mumbai", new HashMap<String, Integer>() {
                {
                    put("mumbai", 42);
                    put("central mumbai", 34);
                    put("south mumbai", 21);
                    put("western mumbai", 35);
                    put("pune", 127);
                    put("nagpur", 767);
                    put("thane", 26);
                    put("kalyan", 31);
                    put("ulhasnagar", 34);
                }
            });
            put("central mumbai", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 14);
                    put("mumbai", 10);
                    put("south mumbai", 16);
                    put("western mumbai", 2);
                    put("pune", 161);
                    put("nagpur", 782);
                    put("thane", 35);
                    put("kalyan", 54);
                    put("ulhasnagar", 59);
                }
            });
            put("south mumbai", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 22);
                    put("central mumbai", 14);
                    put("mumbai", 11);
                    put("western mumbai", 22);
                    put("pune", 148);
                    put("nagpur", 770);
                    put("thane", 23);
                    put("kalyan", 42);
                    put("ulhasnagar", 47);
                }
            });
            put("western mumbai", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 35);
                    put("central mumbai", 4);
                    put("south mumbai", 18);
                    put("mumbai", 6);
                    put("pune", 160);
                    put("nagpur", 787);
                    put("thane", 23);
                    put("kalyan", 43);
                    put("ulhasnagar", 60);
                }
            });
            put("pune", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 129);
                    put("central mumbai", 161);
                    put("south mumbai", 148);
                    put("western mumbai", 160);
                    put("mumbai", 148);
                    put("nagpur", 761);
                    put("thane", 155);
                    put("kalyan", 152);
                    put("ulhasnagar", 157);
                }
            });
            put("nagpur", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 767);
                    put("central mumbai", 782);
                    put("south mumbai", 770);
                    put("western mumbai", 787);
                    put("pune", 761);
                    put("mumbai", 770);
                    put("thane", 752);
                    put("kalyan", 782);
                    put("ulhasnagar", 655);
                }
            });
            put("thane", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 26);
                    put("central mumbai", 35);
                    put("south mumbai", 23);
                    put("western mumbai", 23);
                    put("pune", 155);
                    put("mumbai", 120);
                    put("nagpur", 752);
                    put("kalyan", 25);
                    put("ulhasnagar", 29);
                }
            });
            put("kalyan", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 31);
                    put("central mumbai", 54);
                    put("south mumbai", 42);
                    put("western mumbai", 43);
                    put("pune", 152);
                    put("mumbai", 65);
                    put("nagpur", 782);
                    put("thane", 25);
                    put("ulhasnagar", 5);
                }
            });
            put("ulhasnagar", new HashMap<String, Integer>() {
                {
                    put("navi mumbai", 28);
                    put("central mumbai", 50);
                    put("south mumbai", 38);
                    put("western mumbai", 39);
                    put("pune", 148);
                    put("mumbai", 61);
                    put("nagpur", 776);
                    put("thane", 20);
                    put("kalyan", 5);
                }
            });
        }
    };

    public static String[] getClosestLocations(String location) {
        // get the cloest location to given location
        HashMap<String, Integer> locationData = locationMap.get(location);
        // locationData will be none if location is not present
        if (locationData != null) {
            // put current locatiobn with distance as 0
            locationData.put(location, 0);
            // sort locations by distance
            List<Map.Entry<String, Integer>> list = new ArrayList<>(locationData.entrySet());
            list.sort(Map.Entry.comparingByValue());
            // convert result from list to string array
            String[] closestLocations = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                closestLocations[i] = list.get(i).getKey();
            }
            return closestLocations;
        }
        return null;
    }

    public static Integer getDistanceBetween(String fromLocation, String toLocation) {
        if (fromLocation.equalsIgnoreCase(toLocation)) {
            return 0;
        }
        HashMap<String, Integer> locationData = locationMap.get(fromLocation);
        if (locationData != null) {
            return locationData.get(toLocation);
        }
        return null;
    }

    public static String[] getAvailableLocations() {
        return locationMap.keySet().toArray(new String[0]);
    }
}